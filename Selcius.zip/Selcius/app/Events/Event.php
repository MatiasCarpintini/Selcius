<?php

namespace Selcius\Events;

abstract class Event
{
    //
}
