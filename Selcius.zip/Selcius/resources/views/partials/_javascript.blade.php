<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
<!--Materialize-->
<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script src="/js/materialize.min.js"></script>
<script src="/js/materialize.js"></script>
<!--EndMaterialize-->
<script src="/js/dropzone.js"></script> 

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<!--<script type="css/styles.js"></script>-->
<script src="/js/app.js"></script>

<!-- Include JS files. -->
  <script type="text/javascript" src="/js/froala_editor.min.js"></script>

  <!-- Include Code Mirror. -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.3.0/codemirror.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.3.0/mode/xml/xml.min.js"></script>

  <!-- Include Plugins. -->
  <script type="text/javascript" src="/js/plugins/align.min.js"></script>
  <script type="text/javascript" src="/js/plugins/char_counter.min.js"></script>
  <script type="text/javascript" src="/js/plugins/code_beautifier.min.js"></script>
  <script type="text/javascript" src="/js/plugins/code_view.min.js"></script>
  <script type="text/javascript" src="/js/plugins/colors.min.js"></script>
  <script type="text/javascript" src="/js/plugins/emoticons.min.js"></script>
  <script type="text/javascript" src="/js/plugins/entities.min.js"></script>
  <script type="text/javascript" src="/js/plugins/file.min.js"></script>
  <script type="text/javascript" src="/js/plugins/font_family.min.js"></script>
  <script type="text/javascript" src="/js/plugins/font_size.min.js"></script>
  <script type="text/javascript" src="/js/plugins/fullscreen.min.js"></script>
  <script type="text/javascript" src="/js/plugins/image.min.js"></script>
  <script type="text/javascript" src="/js/plugins/image_manager.min.js"></script>
  <script type="text/javascript" src="/js/plugins/inline_style.min.js"></script>
  <script type="text/javascript" src="/js/plugins/line_breaker.min.js"></script>
  <script type="text/javascript" src="/js/plugins/link.min.js"></script>
  <script type="text/javascript" src="/js/plugins/lists.min.js"></script>
  <script type="text/javascript" src="/js/plugins/paragraph_format.min.js"></script>
  <script type="text/javascript" src="/js/plugins/paragraph_style.min.js"></script>
  <script type="text/javascript" src="/js/plugins/quick_insert.min.js"></script>
  <script type="text/javascript" src="/js/plugins/quote.min.js"></script>
  <script type="text/javascript" src="/js/plugins/table.min.js"></script>
  <script type="text/javascript" src="/js/plugins/save.min.js"></script>
  <script type="text/javascript" src="/js/plugins/url.min.js"></script>
  <script type="text/javascript" src="/js/plugins/video.min.js"></script>