<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Error 502 - Puerta de enlace incorrecta!</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
</head>
<body>
  <div align="center" class="container">
    <p style="font-size: 60px;font-family: 'Lato', sans-serif;color: #ffbb33;"><i style="color: #ff4444;" class="fa fa-link"></i> <b style="color: #FF8800">502!</b></p>
    <p style="color: #00695c;font-family: 'Quicksand', sans-serif;font-size: 20px;">Puerta de enlace incorrecta.</p>
    </div>
  </body>
</html>