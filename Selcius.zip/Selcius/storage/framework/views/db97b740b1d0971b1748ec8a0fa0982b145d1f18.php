<?php echo $__env->make('charts::_partials/container.div-titled', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script type="text/javascript">
    $(function (){
        Morris.Line({
            element: "<?php echo e($model->id); ?>",
            resize: true,
            data: [
                <?php for($l = 0; $l < count($model->values); $l++): ?>
                    {
                        x: "<?php echo e($model->labels[$l]); ?>",
                        y: "<?php echo e($model->values[$l]); ?>"
                    },
                <?php endfor; ?>
            ],
            xkey: 'x',
            ykeys: ['y'],
            labels: ["<?php echo e($model->element_label); ?>"],
            hideHover: 'auto',
            parseTime: false,
            <?php if($model->colors): ?>
                lineColors: ["<?php echo e($model->colors[0]); ?>"],
            <?php endif; ?>
        })
    });
</script>
