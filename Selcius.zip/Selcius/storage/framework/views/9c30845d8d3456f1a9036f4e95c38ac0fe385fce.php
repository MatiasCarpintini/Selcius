<?php $__env->startSection('title', '| Payment'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-10 col-md-offset-1">
			<div class="panel panel-default">
				<div class="panel-heading">Payment</div>
 
				<div class="panel-body">
					<form action="" method="POST">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                      <script
                        src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                        data-key="pk_test_5AdyS9TXjBTjLjjIiABf4dTb"
                        data-amount="10000"
                        data-name="Pago Mensual"
                        data-description="100.00 $ "
                        data-image="https://stripe.com/img/documentation/checkout/marketplace.png">
                      </script>
                    </form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>