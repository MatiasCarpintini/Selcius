<?php $__env->startSection('title', '| Artículos'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
	<?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	<article>
		<div class="col-md-4">
			<a href="<?php echo e(route('articulo.single', $articulo->slug)); ?>">
				<div class="card hoverable">
					<div class="card-image">
						<img class="responsive-img" src="<?php echo e(asset('images/'.$articulo->image)); ?>">
						<span class="card-title"><p><?php echo e($articulo->title); ?></p></span>
					</div>
				<div class="card-content">
					<p><img class="responsive-img" src="<?php echo e(asset('avatars/'.$articulo->user->image)); ?>" style="width: 42px;height: 42px;border-radius: 50%;margin-right: 10px;"> By <a href="<?php echo e('auth.profiles', $articulo->user->id); ?>"> <?php echo $articulo->user->name; ?> </a></p>
				</div>
			</div></a>
		</div>
	</article>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
<div class="row">
	<div class="col-md-12">
		<div class="text-center">
			<?php echo $articulos->links(); ?>

		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>