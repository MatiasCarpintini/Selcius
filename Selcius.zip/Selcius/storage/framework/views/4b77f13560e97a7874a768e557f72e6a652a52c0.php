<script type="text/javascript">
    google.charts.load('current', {'packages':['bar']})

    google.charts.setOnLoadCallback(draw<?php echo e($model->id); ?>)
        function draw<?php echo e($model->id); ?>() {
        var data = google.visualization.arrayToDataTable([
            ['', "<?php echo e($model->element_label); ?>"],
            <?php for($i = 0; $i < count($model->values); $i++): ?>
                ["<?php echo e($model->labels[$i]); ?>", <?php echo e($model->values[$i]); ?>],
            <?php endfor; ?>
        ])

        var options = {
            chart: {
              <?php if($model->title): ?>
                title: "<?php echo e($model->title); ?>",
              <?php endif; ?>
            },
            <?php if($model->colors): ?>
                colors: ["<?php echo e($model->colors[0]); ?>"],
            <?php endif; ?>
        };

        var <?php echo e($model->id); ?> = new google.charts.Line(document.getElementById("<?php echo e($model->id); ?>"))

        <?php echo e($model->id); ?>.draw(data, options)
    }
</script>

<?php echo $__env->make('charts::_partials.container.div', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
