<?php $__env->startSection('title', '| Tecnologías'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
		<div class="col-md-8">
			<h1 class="text-center">Tecnologias</h1>
			<table class="table">
				<thead>
					<tr>
						<th>#</th>
						<th>Nombre</th>
					</tr>
				</thead>
				<tbody>
				<?php foreach($tecnologias as $tecnologia): ?>
					<tr>
						<th>
							<?php echo e($tecnologia->id); ?>

						</th>
						<td>
							<a href="<?php echo e(route('tecnologias.show', $tecnologia->id)); ?>"><?php echo e($tecnologia->name); ?></a>
						</td>
                        <td>
                            <img src="<?php echo e(asset('images/'.$tecnologia->image)); ?>" class="user-image">
                        </td>
					</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<div class="col-md-4">
			<div class="well">
				<?php echo Form::open(['route' => 'tecnologias.store', 'method' => 'POST', 'files' => true]); ?>


				<h2>Añadir Tecnología</h2>

				<?php echo e(Form::label('name', 'Nombre:')); ?>

				<?php echo e(Form::text('name', null, ['class' => 'form-control'])); ?>


                <?php echo e(Form::label('featured_image', 'Icono')); ?>

                <?php echo e(Form::file('featured_image')); ?>


                <?php echo e(Form::text('user_id', Auth::user()->id, ['class' => 'form-control','required' => '', 'readOnly', 'style' => 'visibility: hidden;'])); ?>


				<?php echo e(Form::submit('Aceptar', ['class' => 'btn btn-success btn-block btn-h1-spacing'])); ?>


				<?php echo Form::close(); ?>


			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>