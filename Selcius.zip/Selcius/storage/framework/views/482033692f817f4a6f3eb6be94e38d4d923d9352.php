<?php $titleTag = htmlspecialchars($curso->title); ?>

<?php $__env->startSection('title', "| $titleTag"); ?>


<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->id == $curso->user_id): ?><link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Fredoka+One" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
<div class="row">
  <div class="col-md-13">
    <section align="left">
      <iframe width="728" height="415" align="left"  src="http://www.youtube.com/embed/<?php echo e($curso->video); ?>?theme=light&showinfo=0" frameborder="0"></iframe>
    </section>
    <div class="col-md-4">
      <div class="card">
        <div class="card-image waves-effect waves-block waves-light">

        </div>
        <div class="card-content">
          <p><img src="<?php echo e(asset('avatars/'.$curso->user->image)); ?>" style="width: 42px;height: 42px;border-radius: 50%;margin-right: 10px;"> By <a href="<?php echo e(route('auth.profiles', $curso->user->id)); ?>"> <?php echo e($curso->user->name); ?></a></p>
          <img style="margin-left: 20px;" class="activator" src="/img/video-camera.png">
          <p style="margin-top: 20px;"><span class="card-title activator grey-text text-darken-4">Contenido<i class="material-icons right">more_vert</i></span></p>
        </div>
        <div class="card-reveal">
          <span class="card-title grey-text text-darken-4">Contenido del curso<i class="material-icons right">close</i></span>
          <br>
          <li class="divider"></li>
          <br>
            <?php $__currentLoopData = $uploads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upload): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <?php if($upload->curso_id != $curso->id): ?>
                <?php else: ?>
                  <p style="font-family: 'Nunito', sans-serif;font-size: 25px;"><a href="<?php echo e(route('class.show', $upload->slug)); ?>"><?php echo $upload->title; ?></a></p>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
    <p style="font-family: 'Fredoka One', cursive;font-size:40px;" class="text-center"><img style="margin-right: 10px;" src="<?php echo e(asset('images/'.$curso->icono)); ?>" class="circle"><?php echo e($curso->title); ?></p>
    <p><?php echo $curso->description; ?></p>
    <li class="divider"></li>
    <br>
    <p style="font-size: 30px;font-family: 'Fredoka One', sans-serif;color: #33b5e5;" align="center"> <?php echo e($curso->comentarios()->count()); ?> Comentario/s</p>
    <br>
    <?php if($curso->comentarios->count() == 0): ?>

    <?php else: ?>
    <div class="row">
      <div class="col-md-12 col-xs-12">
        <div class="converstation">
          <?php $__currentLoopData = $curso->comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <div class="media-body">
                    <div class="clearfix">
                        <a href="<?php echo e(route('auth.profiles', $comentario->user->id)); ?>"><p style="font-size: 40px;" class="media-heading">
                        <img class="img-circle" style="width: 52px;height: 52px;border-radius: 50%;margin-right: 10px;" src="<?php echo e(asset('avatars/'.$comentario->user->image)); ?>">
                        <?php echo e($comentario->user->name); ?>

                        </p></a>
                    </div>
                    <p><?php echo e($comentario->comentario); ?></p>
                    <span class="time pull-right"><i class="fa fa-clock-o"></i> <?php echo e(date('F nS, Y - g:iA', strtotime($comentario->created_at))); ?></span>
                    <?php if(Auth::guest()): ?>

                    <?php else: ?>
                      <?php echo e(Form::open(['route' => ['comentarios.destroy', $comentario->id], 'method' => "DELETE"])); ?>

                      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                      <button class="btn-floating btn-large waves-effect waves-light red" type="submit"><i class="material-icons">delete</i></button>
                      <a class="btn-floating btn-large waves-effect waves-light blue" href="<?php echo e(route('comentarios.edit', $comentario->id)); ?>"><i class="material-icons">mode_edit</i></a>
                      <?php echo e(Form::open()); ?>

                  <?php endif; ?>
                </div>
            </div>
            <br>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </div>
    </div>
  <?php endif; ?>
  <div class="row">
    <div class="col-md-12 col-xs-12">
    <div class="converstation">
        <?php if(Auth::guest()): ?>
        <link href="https://fonts.googleapis.com/css?family=Baloo+Thambi" rel="stylesheet">
          <div class="media">
            <div class="media-left">
              <i class="fa fa-user fa-5x" style="margin-right: 10px;"></i>
            </div>
            <div class="media-body">
              <textarea class="materialize-textarea" disabled style="margin-top: 10px;" cols="40" rows="10"></textarea>
              <a disabled style="margin-left: 20px;margin-top: 10px;" class="waves-effect waves-red btn blue" onclick="Materialize.toast('Para participar de los comentarios debes Iniciar Sesión/Registrarte.', 4000)"><i class="material-icons left">send</i>submit</a>
            </div>
            <div class="media" align="center">
              <p style="font-family: 'Baloo Thambi', cursive;font-size: 35px;"><a href="<?php echo e(route('login')); ?>"><i class="fa fa-sign-in" aria-hidden="true"></i> inicia sesión </a> / <a href="<?php echo e(route('register')); ?>"><i class="fa fa-user-plus" aria-hidden="true"></i> registrate </a></p>
            </div>
          </div>
            <?php else: ?>
            <div class="media">
            <div class="media-body">
              <form action="<?php echo e(route('comentarios.store', $curso->id)); ?>" method="POST" id="comment-save">
              <?php echo e(csrf_field()); ?>

              <p><img src="<?php echo e(asset('avatars/'.Auth::user()->image)); ?>" style="margin-left:20px;width: 52px;height: 52px;border-radius: 50%;margin-right: 10px;" class="circle"><?php echo e(Auth::user()->name); ?></p>
                <textarea class="materialize-textarea" style="margin-left: 20px;" name="comentario" cols="40" rows="10"></textarea>
                <input name="user_id" value="<?php echo e(Auth::user()->id); ?>" hidden></input>
                <button type="submit" style="margin-left: 20px;margin-top: 10px;" class="waves-effect waves-red btn blue"> <i class="material-icons left">send</i>submit</button>
              </form>
            </div>
          </div>
        <?php endif; ?>
    </div>
  </div>
</div>
<div class="fixed-action-btn horizontal">
	<a class="btn-floating btn-large red">
		<i class="large material-icons">menu</i>
	</a>
	<ul>
		<?php echo Form::open(['route' => ['cursos.destroy', $curso->id], 'method' => 'DELETE']); ?>

		<li><a class="btn-floating red" href="<?php echo e(route('cursos.edit', $curso->id)); ?>"><i class="fa fa-pencil"></i></a></li>
		<li><a class="btn-floating green darken-1" href="<?php echo e(route('class.create')); ?>"><i class="fa fa-cloud-upload"></i></a></li>
		<li><button class="btn-floating yellow" type="submit"><i class="fa fa-trash-o"></i></button></li>
		<?php echo Form::close(); ?>

	</ul>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>