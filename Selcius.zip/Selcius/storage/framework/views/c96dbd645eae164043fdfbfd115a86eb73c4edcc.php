<?php $__env->startSection('title', '| New Discussion'); ?>

<?php $__env->startSection('content'); ?>

	<div class="row">
		<p class="text-center" style="font-size: 40px;">New Discussion</p>
			<br>
		<?php echo Form::open(['route' => 'discussions.store', 'method' => 'POST']); ?>


			<div class="input-field col s6">
	          <input name="title" id="title" type="text" class="validate">
	          <label for="title">Título</label>
	        </div>
	        <div class="input-field col s6">
	        	<input name="slug" type="text" id="slug" class="validate">
	        	<label for="slug">Slug</label>
	        </div>
	        <div class="row">
			    <form class="col s12">
			      <div class="row">
			        <div class="input-field col s12">
			          <textarea name="body" id="body" class="materialize-textarea"></textarea>
			          <label for="body">Body</label>
			        </div>
			      </div>
			    </form>
			</div>
			<div class="input-field col s6">
				<input type="text" name="user_id" value="<?php echo e(Auth::user()->id); ?>" class="validate" style="visibility: hidden;">
			</div>
			<button class="btn waves-effect waves-light" type="submit" name="action">Enviar
			    <i class="material-icons right">send</i>
			</button>
		<?php echo Form::close(); ?>

	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>