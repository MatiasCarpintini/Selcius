<?php $__env->startSection('title', '| Secciones'); ?>

<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->level == 2): ?>
<div class="row">
		<div class="col-md-10 col-md-offset-1">
		<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
			<p class="text-center" style="font-size: 30px;font-family: 'Quicksand', sans-serif;"><i class="fa fa-folder"></i> Secciones</p>
			<table class="table">
				<thead>
					<tr>
						<th>#</th>
						<th>Icono</th>
						<th>Nombre</th>
						<th style="width: 40px">Acciones</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach($sections as $section): ?>
					<tr>
						<th>
							<?php echo e($section->id); ?>

						</th>
						<th><img src="<?php echo e(asset('images/'.$section->icono)); ?>" style="width: 42px;height: 42px;border-radius: 50%;margin-right: 10px;"></th>
						<td>
							<a href="<?php echo e(route('sections.show', $section->id)); ?>"><?php echo e($section->name); ?> </a>
						</td>
						<td><a href="<?php echo e(route('sections.edit', $section->id)); ?>" class="btn-flat waves-effect"><i class="fa fa-pencil"></i></a></td>
						<td>
     
						<?php echo Form::open(['route' => ['sections.destroy', $section->id], 'method' => 'DELETE']); ?>

						<button type="submit" class="btn-flat waves-effect"><i class="material-icons">delete</i></button>
						<?php echo Form::close(); ?>

						</td>
					</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<br>
			<li class="divider"></li>
			<br>
			<?php echo Form::open(['route' => 'sections.store', 'method' => 'POST', 'files' => 'true']); ?>

			<p class="text-center" style="font-size: 30px;font-family: 'Quicksand', sans-serif;"><i class="fa fa-plus"></i> Nueva sección</p>
			<br>
				
				<div class="input-field col s6">
				  <i class="fa fa-folder prefix"></i>
		          <label for="name">Nombre</label>
				  <input type="text" id="name" name="name">
		    </div>
				<div class="file-field input-field col s6">
					<div class="btn">
						<span>File</span>
						<input name="featured_icono" type="file">
					</div>
					<div class="file-path-wrapper">
						<input class="file-path validate" type="text">
					</div>
				</div>
				<br>
				<br>
				<button class="btn waves-effect waves-light blue" type="submit" name="action">send
    				<i class="material-icons right">send</i>
  				</button>
			</div>
			<?php echo Form::close(); ?>

	</div>
<?php else: ?>
<div class="row">
	<div class="col-md-10 col-md-offset-1">
	<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
		<p style="font-size: 30px;font-family: 'Quicksand', sans-serif;" class="text-center"><i class="fa fa-puzzle-piece"></i> Secciones</p>
			<?php foreach($sections as $section): ?>
				<a href="<?php echo e(route('sections.show', $section->id)); ?>"><div style="float:center;" class="chip">
					<img src="<?php echo e(asset('images/'.$section->icono)); ?>" class="circle"><?php echo e($section->name); ?>

				</div></a>
			<?php endforeach; ?>
	</div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>