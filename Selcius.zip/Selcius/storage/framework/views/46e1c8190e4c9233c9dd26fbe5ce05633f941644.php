<?php $titleTag = htmlspecialchars($user->name); ?>
<?php $__env->startSection('title', "| $titleTag"); ?>

<?php $__env->startSection('content'); ?>
    <link href="https://fonts.googleapis.com/css?family=Fredoka+One" rel="stylesheet">
    <div class="card">
        <div class="card-image">
        <br>
        <p class="text-center" style="font-size: 40px;font-family: 'Fredoka One', cursive;"><img src="<?php echo e(asset('avatars/'.$user->image)); ?>" style="width: 64px;height: 64px;border-radius: 50%;" class="profile-user-img responsive-img img-circle"><?php echo e($user->name); ?><?php if($user->level == 2): ?> <i class="fa fa-bolt" aria-hidden="true" ></i> <?php else: ?> <?php if($user->stripe_active == 1): ?>  <i class="fa fa-diamond" style="color: #CC0000;" aria-hidden="true"></i> <?php endif; ?> <?php endif; ?></p>
        </div>
        <li class="divider"></li>
        <div class="card-content">
        <link href="https://fonts.googleapis.com/css?family=Spinnaker" rel="stylesheet">
        <p style="font-family: 'Spinnaker', sans-serif;font-size: 20px;" align="center"><?php echo e($user->description); ?></p>
        <br>
        <li class="divider"></li>
        <br>
        <div class="row" align="center">
          <?php if($user->facebook != ""): ?>
          <a href="https://www.facebook.com<?php echo e(Auth::user()->facebook); ?>" class="btn-floating btn-large waves-effect waves-light" style="background-color: #3b5998;"><i class="fa fa-facebook" style="color:white;"></i></a>
          <?php endif; ?>
          <?php if($user->twitter != ""): ?>
          <a href="https://www.twitter.com<?php echo e(Auth::user()->twitter); ?>" class="btn-floating btn-large waves-effect waves-light" style="background-color: #00aced;"><i class="fa fa-twitter" style="color:white;"></i></a>
          <?php endif; ?>
          <?php if($user->github != ""): ?>
          <a href="https://www.github.com<?php echo e(Auth::user()->github); ?>" class="btn-floating btn-large waves-effect waves-light" style="background-color: #303030;"><i class="fa fa-github" style="color:white;"></i></a>
          <?php endif; ?>
          <?php if($user->linkedin != ""): ?>
          <a href="https://www.linkedin.com<?php echo e(Auth::user()->linkedin); ?>" class="btn-floating btn-large waves-effect waves-light" style="background-color: #0077b5;"><i class="fa fa-linkedin" style="color:white;"></i></a>
          <?php endif; ?>
          <?php if($user->youtube != ""): ?>
          <a href="https://www.youtube.com<?php echo e(Auth::user()->youtube); ?>" class="btn-floating btn-large waves-effect waves-light" style="background-color: #cd201f;"><i class="fa fa-youtube-play" style="color:white;"></i></a>
          <?php endif; ?>
          <?php if($user->website != ""): ?>
          <a href="<?php echo e(Auth::user()->website); ?>" class="btn-floating btn-large waves-effect waves-light" style="background-color: #00C851;"><i class="fa fa-link" style="color:white;"></i></a>
          <?php endif; ?>
        </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>