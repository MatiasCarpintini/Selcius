<?php $__env->startSection('title', '| Chat'); ?>
<?php $__env->startSection('stylesheets'); ?>
<?php echo e(Html::style('css/chat.css')); ?>

<?php echo e(Html::style('css/uielement.css')); ?>

<script type="text/javascript" src="<?php echo e(asset('js/jquery-ajax-fileupload.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/socket.js')); ?>"></script>
	<script>window.appSocket = new Socket("ws://<?php echo e(str_replace('/', '', explode(':', url('/'))[1])); ?>:<?php echo e(config('socket.default_port')); ?>");</script>
	<script type="text/javascript" src="<?php echo e(asset('js/chat.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-2">
			<div class="row" id="contacts-sidebar">
				<?php foreach(Auth::user()->channels as $channel): ?>
				<a class="col-md-12 chat-grid" onclick="channelSelected(<?php echo e($channel->id); ?>)">
					<span id="<?php echo e($channel->id); ?>-online-status" class="hasnotification hasnotification-<?php echo e(($channel->otherUser()->is_online == 1) ? 'success' : 'default'); ?> mr5"></span>
					<?php echo e($channel->otherUser()->name); ?>

					<span id="unread-<?php echo e($channel->id); ?>"><?php echo e($channel->unreadMessagesCount()); ?></span>
				</a>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="col-md-10">
			<div class="panel panel-default" id="chat-panel">
  				<div class="panel-heading" id="chat-heading"><?php echo e(str_replace('/', '', explode(':', url('/'))[1])); ?></div>
  				<div class="panel-body" id="chat-body"></div>
  				<div class="panel-footer" id="chat-footer">
  					<div class="row">
  						<div class="col-md-1">
							<label class="btn btn-primary">
    							File
    							<input type="file" id="chat-file-input" style="display: none;">
							</label>
						</div>
  						<div class="col-md-10">
  							<input type="text" class="form-control" id="message-text" placeholder="Write message here..."/>
  						</div>
  						<div class="col-md-1">
  							<button class="btn btn-default" onclick="sendTextMessage()">Send</button>
  						</div>
  					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>