<?php $titleTag = htmlspecialchars($category->name); ?>
<?php $__env->startSection('title', "| Categoría $titleTag"); ?>

<?php $__env->startSection('content'); ?>

<?php if(Auth::guest()): ?>

<?php else: ?>
<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
<p class="text-center" style="font-size: 30px; font-family: 'Quicksand', sans-serif;"> Todos los artículos que se encuentran el la categoría: <i class="fa fa-puzzle-piece"></i> <?php echo e($category->name); ?> (<?php echo e($category->articulos->count()); ?>)</p>
<br>
<div class="row">
	<?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <?php if($category->id == $articulo->category_id): ?>
        <article>
            <div class="col-md-4">
                <a href="<?php echo e(route('articulo.single', $articulo->slug)); ?>"><div class="card hoverable">
                    <div class="card-image">
                        <img class="responsive-img" src="<?php echo e(asset('images/'.$articulo->image)); ?>">
                        <span class="card-title"><p><?php echo e($articulo->title); ?></p></span>
                    </div>
                    <div class="card-content">
                        <p style="color: black;"><?php echo e(substr(strip_tags($articulo->body), 0, 150)); ?><?php echo e(strlen(strip_tags($articulo->body)) > 150 ? '...' : ""); ?></9p>
                    </div>
                </div></a>
            </div>
        </article>
        <?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>