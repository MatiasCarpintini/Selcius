<?php $titleTag = htmlspecialchars($articulo->title); ?>
<?php $__env->startSection('title', "| $titleTag"); ?> 
<?php $__env->startSection('content'); ?>
<?php if(Auth::guest()): ?>
<?php else: ?>
<?php if(Auth::user()->level == 2): ?>
<div class="row">
	<div class="col-md-8">
		<img class="materialboxed" src="<?php echo e(asset('images/'.$articulo->image)); ?>">
		<link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
		<p style="font-size: 35px;font-family: 'Ubuntu', sans-serif;"><?php echo e($articulo->title); ?></p>
		<p class="lead"><?php echo $articulo->body; ?>}</p>
		<hr>
		<div class="tags">
			<?php $__currentLoopData = $articulo->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

			<span class="label label-default"> 
				<?php echo e($tag->name); ?>

			</span>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</div>
	<div id="backend-comments" style="margin-top: 50px;">
	<link href="https://fonts.googleapis.com/css?family=Varela+Round" rel="stylesheet">
		<p style="font-size: 35px;font-family: 'Varela Round', sans-serif;color: #33b5e5;" class="text-center"><i class="fa fa-comments-o"></i> <?php echo e($articulo->comments()->count()); ?> Comentarios</p>
			<table class="bordeder">
				<thead>
					<tr>
						<th>Nombre</th>
						<th>E-mail</th>
						<th>Created At</th>
						<th>Updated At</th>
						<th>Acciones</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $articulo->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					<tr>
						<td><a href="<?php echo e(route('auth.profiles', $comment->user->id)); ?>"><img src="<?php echo e(asset('avatars/'.$comment->user->image)); ?>" style="width: 42px;height: 42px;border-radius: 50%;margin-right: 10px;"><?php echo e($comment->user->name); ?> </a></td>
						<td><?php echo e($comment->user->email); ?></td>
						<td><?php echo e(date('M j, Y h:ia', strtotime($comment->created_at))); ?></td>
						<td><?php echo e(date('M j, Y h:ia', strtotime($comment->updated_at))); ?></td>
						<td>
							<?php echo Form::open(['route' => ['comments.destroy', $comment->id], 'method' => 'DELETE']); ?>

							<a href="<?php echo e(route('comments.edit', $comment->id)); ?>" style="margin-right: 10px;"><i class="glyphicon glyphicon-pencil"></i></a>
							<button type="submit"><i class="glyphicon glyphicon-trash"></i></button>
							<?php echo Form::close(); ?>

						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</tbody>
			</table>
		</div>
	</div>
	<div class="col-md-4">
		<div class="well">
			<dl class="dl-horizontal">
				<a href="<?php echo e(route('auth.profiles', $articulo->user->id)); ?>"><p class="text-center"><img src="<?php echo e(asset('avatars/'.$articulo->user->image)); ?>" style="width: 42px;height: 42px;border-radius: 50%;margin-right: 10px;"><?php echo e($articulo->user->name); ?></p></a>
			</dl>
			<dl class="dl-horizontal">
				<p><i class="fa fa-unlink"></i> Slug: <a href="<?php echo e(route('articulo.single', $articulo->slug)); ?>"><?php echo e(route('articulo.single', $articulo->slug)); ?></a></p>
			</dl>
			<dl class="dl-horizontal">
				<p><i class="fa fa-puzzle-piece"></i> Categoría: <?php echo e($articulo->category->name); ?></p>
			</dl>
			<dl class="dl-horizontal">
				<p><i class="fa fa-clock-o"></i> Creado el: <?php echo e(date('M j, Y h:ia', strtotime($articulo->created_at))); ?></p>
			</dl>
			<dl class="dl-horizontal">
				<p><i class="fa fa-clock-o"></i> Última actualización: <?php echo e(date('M j, Y h:ia',strtotime($articulo->updated_at))); ?></p>
			</dl>
			<li class="divider"></li>
			<br>
			<div class="row">
				<div class="col-sm-6">
					<?php echo Form::open(['route' => ['articulos.destroy', $articulo -> id], 'method' => 'DELETE']); ?>

						<button type="submit" class="waves-effect waves-light btn red"><i class="fa fa-trash right"></i> delete</button>
					<?php echo Form::close(); ?>

				</div>
				<div class="col-sm-6">
					<a href="<?php echo e(route('articulos.edit', $articulo->id)); ?>" class="btn blue waves-effect waves-light"><i class="fa fa-pencil right"></i> edit</a>
				</div>
			</div>
			<div class="col-md-12 text-center">
				<a href="<?php echo e(route('articulos.index')); ?>" class="waves-effect waves-light default btn"><i class="fa fa-newspaper-o right"></i> back</a>
			</div>
			<br>
			<br>
		</div>
	</div>
</div>
<?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>