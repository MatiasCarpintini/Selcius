<?php $__env->startSection('title', '| Categorías'); ?>
<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->level == 2): ?>
	<div class="row">
		<div class="col-md-10 col-md-offset-1">
		<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
			<p class="text-center" style="font-size: 30px;font-family: 'Quicksand', sans-serif;"><i class="fa fa-puzzle-piece"></i> Categorías</p>
			<table class="table" id="table">
				<thead>
					<tr>
						<th>#</th>
						<th>Nombre</th>
						<th style="width: 40px">Acciones</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					<tr class="item<?php echo e($category->id); ?>">
						<th>
							<?php echo e($category->id); ?>

						</th>
						<td id="name">
							<a href="<?php echo e(route('categories.show', $category->id)); ?>"><?php echo e($category->name); ?></a>
						</td>
						<td><a href="<?php echo e(route('categories.edit', $category->id)); ?>" class="btn-flat waves-effect"><i class="fa fa-pencil"></i></a></td>
						<td>
						<?php echo Form::open(['route' => ['categories.destroy', $category->id], 'method' => 'DELETE']); ?>

						<button type="submit" class="btn-flat waves-effect"><i class="material-icons">delete</i></button>
						<?php echo Form::close(); ?>

						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</tbody>
			</table>
			<br>
			<li class="divider"></li>
			<br>
			<p class="text-center" style="font-size: 30px;font-family: 'Quicksand', sans-serif;"><i class="fa fa-plus"></i> Nueva categoría</p>
			<br>
			<div class="col-md-10 col-md-offset-2">
				<input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
				<div class="input-field col s6">
				  <i class="fa fa-puzzle-piece prefix"></i>
		          <label for="name">Nombre</label>
				  <input type="text" id="name" name="name">
		        </div>
				<br>
				<button class="btn waves-effect waves-light blue" id="add" type="submit">enviar
    				<i class="material-icons right">send</i>
  				</button>
			</div>
		</div>
	</div>
<?php else: ?>
<div class="row">
	<div class="col-md-10 col-md-offset-1">
	<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
		<p style="font-size: 30px;font-family: 'Quicksand', sans-serif;" class="text-center"><i class="fa fa-puzzle-piece"></i> Categorías</p>
			<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<a href="<?php echo e(route('categories.show', $category->id)); ?>"><div style="float:center;" class="chip">
					<?php echo e($category->name); ?>

				</div></a>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</div>
</div>
<?php endif; ?>
<script>
var url = "<?php echo e(route('categories.store')); ?>"
$("#add").click(function() {
  $.ajax({
    type: 'post',
    url: url,
    data: {
      '_token': $('input[name=_token]').val(),
      'name': $('input[name=name]').val()
    },
    success: function(data) {
      if ((data.errors)) {
        $('.error').removeClass('hidden');
        $('.error').text(data.errors.name);
      } else {
        $('.error').remove();
        $('#table').append(
        	"<tr class='item"+ data.id +"'><th>"+ data.id +"</th><td><a href='<?php echo e(route('categories.show', $category->id)); ?>'>"+ data.name +"</a></td></tr>"
        	);
      }
    },
  });
  $('#name').val('');
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>