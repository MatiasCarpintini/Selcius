<?php $__env->startSection('title', '| Mi Perfil'); ?>

<?php $__env->startSection('content'); ?>
<?php if(Auth::guest()): ?>

<?php else: ?>
  <link href="https://fonts.googleapis.com/css?family=Fredoka+One" rel="stylesheet">
   <div class="card">
    <div class="card-image">
    <br>
      <p align="center" style="font-size: 40px;font-family: 'Fredoka One', cursive;"><img src="<?php echo e(asset('avatars/'.Auth::user()->image)); ?>" style="width: 64px;height: 64px;border-radius: 50%;" class="profile-user-img responsive-img img-circle"><?php echo e(Auth::user()->name); ?><?php if(Auth::user()->level == 2): ?> <i class="fa fa-bolt" aria-hidden="true" ></i> <?php else: ?> <?php if(Auth::user()->stripe_active == 1): ?>  <i class="fa fa-diamond" style="color: #CC0000;" aria-hidden="true"></i> 
      <?php endif; ?> <?php endif; ?>
      </p>
      <p style="margin: 1.0rem;">
          <i class="fa fa-envelope" aria-hidden="true"></i> <?php echo e(Auth::user()->email); ?> <span style="float: right;"><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e(date('F nS, Y', strtotime(Auth::user()->created_at))); ?></span>
      </p>
    <li class="divider"></li>
    <div class="card-content">
      <link href="https://fonts.googleapis.com/css?family=Spinnaker" rel="stylesheet">
      <p style="font-family: 'Spinnaker', sans-serif;font-size: 20px;" class="text-center"><?php echo e(Auth::user()->description); ?></p>
      <br>
      <li class="divider"></li>
      <br>
      <div class="row" align="center">
        <?php if(Auth::user()->facebook != ""): ?>
        <a href="https://www.facebook.com<?php echo e(Auth::user()->facebook); ?>" class="btn-floating btn-large waves-effect waves-light" style="background-color: #3b5998;"><i class="fa fa-facebook" style="color:white;"></i></a>
        <?php endif; ?>
        <?php if(Auth::user()->twitter != ""): ?>
        <a href="https://www.twitter.com<?php echo e(Auth::user()->twitter); ?>" class="btn-floating btn-large waves-effect waves-light" style="background-color: #00aced;"><i class="fa fa-twitter" style="color:white;"></i></a>
        <?php endif; ?>
        <?php if(Auth::user()->github != ""): ?>
        <a href="https://www.github.com<?php echo e(Auth::user()->github); ?>" class="btn-floating btn-large waves-effect waves-light" style="background-color: #303030;"><i class="fa fa-github" style="color:white;"></i></a>
        <?php endif; ?>
        <?php if(Auth::user()->linkedin != ""): ?>
        <a href="https://www.linkedin.com<?php echo e(Auth::user()->linkedin); ?>" class="btn-floating btn-large waves-effect waves-light" style="background-color: #0077b5;"><i class="fa fa-linkedin" style="color:white;"></i></a>
        <?php endif; ?>
        <?php if(Auth::user()->youtube != ""): ?>
        <a href="https://www.youtube.com<?php echo e(Auth::user()->youtube); ?>" class="btn-floating btn-large waves-effect waves-light" style="background-color: #cd201f;"><i class="fa fa-youtube-play" style="color:white;"></i></a>
        <?php endif; ?>
        <?php if(Auth::user()->website != ""): ?>
        <a href="<?php echo e(Auth::user()->website); ?>" class="btn-floating btn-large waves-effect waves-light" style="background-color: #00C851;"><i class="fa fa-link" style="color:white;"></i></a>
        <?php endif; ?>
      </div>
      <div class="row" align="center" style="float:center;"> 
          <div class="col-md-2"> 
            <a href="https://www.paypal.com/cgi-bin/webscr?cmd=_subscr-find&alias=NM74KYVPK85SN">
                <img src="https://www.paypalobjects.com/en_US/i/btn/btn_unsubscribe_LG.gif" border="0">
            </a>    
        </div>
      </div>
    </div>
    </div>
   </div>
   <div class="fixed-action-btn toolbar">
    <a class="btn-floating btn-large red">
      <i class="large material-icons">menu</i>
    </a>
    <ul>
      <li><a class="waves-effect waves-light" href="<?php echo e(route('auth.profiles', Auth::user()->id)); ?>"><i class="material-icons">visibility</i></a></li>

      <li><a href="<?php echo e(route('auth.edit', Auth::user()->id)); ?>" class="waves-effect waves-light"><i class="material-icons">mode_edit</i></a></li>
    </ul>
  </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>