<?php $__env->startSection('title', '| Tags'); ?>
<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->level == 2): ?>
<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
<div class="row">
	<div class="col-md-10 col-md-offset-1">
		<p style="font-size: 30px;font-family: 'Quicksand', sans-serif;" class="text-center"><i class="fa fa-tags"></i> Tags</h1>
		<table class="table">
			<thead>
				<tr>
					<th>#</th>
					<th>Nombre</th>
					<th style="width: 40px;">Acciones</th>
				</tr>
			</thead>
			<tbody>
			<?php foreach($tags as $tag): ?>
				<tr>
					<th>
						<?php echo e($tag->id); ?>

					</th>
					<td>
						<a href="<?php echo e(route('tags.show', $tag->id)); ?>"><?php echo e($tag->name); ?></a>
					</td>
					<td><a href="<?php echo e(route('tags.edit', $tag->id)); ?>" class="btn-flat waves-effect"><i class="fa fa-pencil"></i></a></td>
					<td>
						<?php echo Form::open(['route' => ['tags.destroy', $tag->id], 'method' => 'DELETE']); ?>

						<button type="submit" class="btn-flat waves-effect"><i class="material-icons">delete</i></button>
						<?php echo Form::close(); ?>

					</td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<br>
		<div id="create-tag">
		<?php echo Form::open(['route' => 'tags.store', 'method' => 'POST']); ?>

		<p class="text-center" style="font-size: 30px;font-family: 'Quicksand', sans-serif;"><i class="fa fa-plus"></i> Nuevo tag</p>
		<section style="padding-bottom: 40px;padding-left: 200px;">
			<div class="input-field col s6">
				<label for="name">Nombre</label>
				<input type="text" name="name" id="name">
			</div>
			<br>
			<button class="btn waves-effect waves-light submit blue" type="submit" name="action">send
				<i class="material-icons right">send</i>
			</button>
		</section>
		<?php echo Form::close(); ?>

		</div>
	</div>
</div>
<?php else: ?>
<div class="row">
	<div class="col-md-10 col-md-offset-1">
	<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
		<p style="font-size: 30px;font-family: 'Quicksand', sans-serif;" class="text-center"><i class="fa fa-tags"></i> Tags</p>
		<?php foreach($tags as $tag): ?>
			<div class="chip">
				<a href="<?php echo e(route('tags.show', $tag->id)); ?>"> <?php echo e($tag->name); ?> </a>
			</div>
		<?php endforeach; ?>
	</div>
</div>
<?php endif; ?>
<script>					
var url = '<?php echo e(url('tags.store')); ?>';
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>