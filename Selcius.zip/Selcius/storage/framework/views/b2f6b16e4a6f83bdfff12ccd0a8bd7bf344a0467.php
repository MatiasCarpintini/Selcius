<?php $titleTag = htmlspecialchars($upload->title); ?>

<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Fredoka+One" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">

<?php $__env->startSection('title', "| $titleTag"); ?>

<?php $__env->startSection('content'); ?>
<?php if(Auth::check()): ?>

<?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	<?php if($upload->curso_id == $curso->id): ?>
		<?php if($curso->level <= Auth::user()->stripe_active): ?>
			<meta name="_token" content="<?php echo csrf_token(); ?>" />
			<div class="row">
				<div class="col-md-13">
					<div class="col-md-8">
						<video  controls preload="auto" data-setup='{}' id="vid1" class="video-js vjs-fluid" >
							<source src="<?php echo e(asset("videos/$upload->file")); ?>" type='video/mp4; codecs="avc1.42c00d"'>
							<source src="<?php echo e(asset("videos/$upload->file")); ?>" type='video/webm; codecs="vorbis,vp8"'>
							<source src="<?php echo e(asset("videos/$upload->file")); ?>" type="video/ogg">
						</video>
					</div>
					<div class="col-md-4">
						<div class="card">
							<div class="card-content">
								<p align="center"><img style="width: 42px;height: 42px;border-radius: 50%;" src="<?php echo e(asset('avatars/'.$upload->user->image)); ?>"><a href="<?php echo e(route('auth.profiles', $upload->user->id)); ?>"><?php echo e($upload->user->name); ?></a></p>
								<br>
								<p align="center"><img src="/img/chat.png" class="responsive-img activator"></p>
								<br><br><br>
								<p><span class="card-title activator grey-text text-darken-4">Chat <i style="margin-top: 10px;" class="material-icons right">more_vert</i></span></p>
							</div>
							<div class="card-reveal">
								<span class="card-title grey-text text-darken-4">Chat<i class="material-icons right">close</i></span>
								<br>
								<li class="divider"></li>
								<br>
									<chat>
										<?php $__currentLoopData = $upload->messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
											<div class="row">
												<div class="direct-chat-msg left">
													<a href="<?php echo e(route('auth.profiles', $message->user->id)); ?>"><img class="direct-chat-img responsive-img" src="<?php echo e(asset('avatars/'.$message->user->image)); ?>" style="width: 32px;height: 32px;border-radius: 50%;margin-right: 10px;"></a>
													<div class="direct-chat-text">
														<?php echo $message->message; ?>

													</div>
												</div>
											</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
									</chat>
									<div class="row">
										<input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
										<textarea required id="chat_message" name="message" class="materialize-textarea"></textarea>
										<button id="send" class="waves-effect waves-light btn blue" type="submit"><i class="material-icons left">send</i>enviar</button>
									</div>
								</div>
							</div>
						</div>
					  </div>
					</div>
					<div class="row"></div>
					<div class="row">
					<p style="font-size: 40px;" class="text-center"><?php echo e($upload->title); ?></p>
					</div>
					<li class="divider"></li>
					<br>
					<div class="row">
						<div class="col-md-13">
						<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
						<p style="font-family: 'Quicksand', sans-serif;font-size: 20px;"><?php echo $upload->description; ?></p>
					</div>
						</div>
					</div>
			<?php endif; ?>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
<?php else: ?>
<div align="center" class="row">
<img src="/img/electricity.png">
<link href="https://fonts.googleapis.com/css?family=Baloo+Thambi" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Nunito+Sans" rel="stylesheet">
<p style="font-family: 'Nunito Sans', sans-serif;font-size: 25px;">Para acceder a este contenido debes </p>
<p style="font-family: 'Baloo Thambi', cursive;font-size: 35px;"><a href="<?php echo e(route('login')); ?>"><i class="fa fa-sign-in" aria-hidden="true"></i> inicia sesión </a> / <a href="<?php echo e(route('register')); ?>"><i class="fa fa-user-plus" aria-hidden="true"></i> registrate </a></p>
</div>
		<?php endif; ?>
	<script type="text/javascript">
	var url = "<?php echo e(route('messages.store', $upload->id)); ?>";
	$("#send").click(function() {
		$.ajax({
		type: 'post',
		url: url,
		data: {
		  '_token': $('input[name=_token]').val(),
		  'message': $('textarea[name=message]').val()
		},
		success: function(data) {
		  if ((data.errors)) {
			$('.error').removeClass('hidden');
			$('.error').text(data.errors.message);
		  } else {
			$('.error').remove();
			$('chat').append(
				<?php if ($upload->messages->count() == 0){ } else{ ?>
					"<div class='row'><div class='direct-chat-msg left'><a href='<?php echo e(route('auth.profiles', $message->user->id)); ?>'><img src='<?php echo e(asset('avatars/'.$message->user->image)); ?>' style='width: 32px;height: 32px;border-radius: 50%;margin-right: 10px;'></a></div><div class='direct-chat-text' id='message'>" + data.message + "</div></div>"
				<?php } ?>				
				);
			$('#chat_message').val(''); 
		  }
		},
		});
		$('#message').val('');
	});
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>