<?php $__env->startSection('title', "| $tag->name Tag"); ?>

<?php $__env->startSection('content'); ?>
<?php if(Auth::guest()): ?>

<?php else: ?>
<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
<p class="text-center" style="font-size: 30px; font-family: 'Quicksand', sans-serif;"> Todos los artículos que están usando el Tag: <i class="fa fa-tag"></i> <?php echo e($tag->name); ?> (<?php echo e($tag->articulos->count()); ?>)</p>
<br>
<div class="row">
	<?php $__currentLoopData = $tag->articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <article>
            <div class="col-md-4">
                <a href="<?php echo e(route('articulo.single', $articulo->slug)); ?>"><div class="card hoverable">
                    <div class="card-image">
                        <img src="<?php echo e(asset('images/'.$articulo->image)); ?>">
                        <span class="card-title"><p><?php echo e($articulo->title); ?></p></span>
                    </div>
                    <div class="card-content">
                        <p><img src="<?php echo e(asset('avatars/'.$articulo->user->image)); ?>" style="width: 42px;height: 42px;border-radius: 50%;margin-right: 10px;"> By <a href="<?php echo e('auth.profiles', $articulo->user->id); ?>"> <?php echo $articulo->user->name; ?> </a></p>
                    </div>
                </div></a>
            </div>
        </article>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>