<?php $__env->startSection('title','| Uploads'); ?>

<?php $__env->startSection('content'); ?>

	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<?php echo e(Form::open(['route' => 'uploads.store','data-parsley-validate' => '', 'method' => 'POST', 'files' => true])); ?>


			<?php echo e(Form::label('title', 'Título')); ?>

			<?php echo e(Form::text('title', null, ['class' => 'form-control'])); ?>


			<?php echo e(Form::label('description', 'Descripción')); ?>

			<?php echo e(Form::textarea('description', null, ['class' => 'form-control fr-view'])); ?>


			<?php echo e(Form::label('featured_file', 'Vídeo')); ?>

			<?php echo e(Form::file('featured_file', null, ['class' => 'form-control'])); ?>


			<?php echo e(Form::text('user_id', Auth::user()->id, ['class' => 'form-control','required' => '', 'readOnly', 'style' => 'visibility: hidden;'])); ?>


			<?php echo e(Form::label('curso_id', 'Curso')); ?>

    		<select class="form-control" name="curso_id">
    		<?php foreach($cursos as $curso): ?>
    			<?php if($curso->user_id != Auth::user()->id): ?>

    			<?php else: ?>
    			<option value='<?php echo e($curso->id); ?>'><?php echo e($curso->title); ?></option>
    			<?php endif; ?>
    		<?php endforeach; ?>
    		</select>

    		<hr>

			<?php echo e(Form::submit('¡Cargar!', ['class' => 'btn btn-primary'])); ?>


			<?php echo e(Form::close()); ?>

		</div>
	</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>