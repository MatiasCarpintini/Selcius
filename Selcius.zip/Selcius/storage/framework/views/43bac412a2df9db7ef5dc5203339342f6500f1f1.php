<?php $titleTag = htmlspecialchars($category->name); ?>

<?php $__env->startSection('title', "| Category Edit $titleTag"); ?>

<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->level == 2): ?>
<div class="row">
	<?php echo Form::model($category, ['route' => ['categories.update', $category->id], 'data-parsley-validate' => '','method' => 'PUT']); ?>

	<div class="col-md-8 col-md-offset-2">
	<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
		<p style="font-family: 'Quicksand', sans-serif;font-size: 30px;" class="text-center">Editar categoría: <?php echo e($category->name); ?></p>
		<br>
		<div class="input-field col-md-offset-1">
			<i class="prefix fa fa-puzzle-piece"></i>
			<label for="name1">Nuevo nombre</label>
			<input type="text" id="name1" name="name">
		</div>
		<br>
		<button class="btn waves-effect waves-light blue" type="submit" name="action">send
			<i class="material-icons right">send</i>
		</button>
		<br>
	<?php echo Form::close(); ?>

	</div>
</div>
<?php else: ?>
<link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
<p class="text-center"><i class="fa fa-puzzle-piece fa-5x"></i></p>
<p class="text-center" style="font-family: 'Comfortaa', cursive;font-size: 40px;">Editar Categoría</p>
<p class="text-center" style="font-family: 'Comfortaa', cursive;font-size: 40px;">Solo administradores</p>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>