<?php $__env->startSection('title', '| Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<?php if(Auth::guest()): ?>

<?php else: ?>
	<?php if(Auth::user()->level == 2): ?>
	<?php echo $chart->render(); ?>

	<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
	<div class="card">
		<div class="card-content">
			<p style="font-size: 40px;font-family: 'Lato', sans-serif;" class="text-center">
			<a style="margin-left: 5px;margin-right: 5px;"> <?php echo e($users->count()); ?> <i class="fa fa-user" aria-hidden="true"></i> </a>
			<a href="<?php echo e(route('articulos.index')); ?>"><?php echo e($articulos->count()); ?> <i class="fa fa-newspaper-o"  style="margin-right: 5px;" aria-hidden="true"></i> </a>
			<a href="<?php echo e(route('cursos.index')); ?>"><?php echo e($cursos->count()); ?> <i class="fa fa-book" style="margin-right: 5px;" aria-hidden="true"></i> </a>
			<a href="<?php echo e(route('foros.index')); ?>"><?php echo e($foros->count()); ?> <i class="fa fa-users" aria-hidden="true"></i> </a>
			</p>
			<br>
			<li class="divider"></li>
			<br>
			<table class="bordered">
				<thead>
					<th>#</th>
					<th>Avatar</th>
					<th>Nombre</th>
					<th>Email</th>
					<th>Level</th>
					<th>Created at</th>
					<th>Updated at</th>
					<th>Stripe Active</th>
					<th>Stripe Plan</th>
				</thead>
				<tbody>
					<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

						<tr>
							<th><?php echo e($user->id); ?></th>
							<th><a href="<?php echo e(route('auth.profiles', $user->id)); ?>"><img src="<?php echo e(asset('avatars/'.$user->image)); ?>" class="circle img-circle user-image" style="width: 42px;height: 42px;border-radius: 50%;margin-right: 10px;"></a></th>
							<th><?php echo e($user->name); ?></th>
							<th><?php echo e($user->email); ?></th>
							<th><?php echo e($user->level); ?></th>
							<th><?php echo e(date('M j, Y h:ia', strtotime($user->created_at))); ?></th>
							<th><?php echo e(date('M j, Y h:ia', strtotime($user->updated_at))); ?></th>
							<th><?php echo e($user->stripe_active); ?></th>
							<th><?php echo e($user->stripe_plan); ?></th>
						</tr>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</tbody>
			</table>
		</div>
	</div>
	<?php else: ?>
	<link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">
	<p class="text-center"><i class="fa fa-tachometer fa-5x" aria-hidden="true"></i></p>
	<p class="text-center" style="font-family: 'Comfortaa', cursive;font-size: 40px;">Dashboard</p>
	<p class="text-center" style="font-family: 'Comfortaa', cursive;font-size: 40px;">Solo administradores</p>
	<?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>