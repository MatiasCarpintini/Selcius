<?php echo $__env->make('charts::_partials/container.div-titled', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script type="text/javascript">
    $(function() {
        Morris.Area({
            element: "<?php echo e($model->id); ?>",
            resize: true,
            data: [
                <?php for($i = 0; $i < count($model->values); $i++): ?>
                    {
                        x: "<?php echo e($model->labels[$i]); ?>",
                        y: <?php echo e($model->values[$i]); ?>

                    },
                <?php endfor; ?>
            ],
            xkey: 'x',
            ykeys: ['y'],
            labels: ["<?php echo e($model->element_label); ?>"],
            hideHover: 'auto',
            parseTime: false,
            <?php if($model->colors): ?>
                lineColors: ["<?php echo e($model->colors[0]); ?>"],
            <?php endif; ?>
        })
    });
</script>
