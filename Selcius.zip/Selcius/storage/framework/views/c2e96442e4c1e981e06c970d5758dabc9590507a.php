<script type="text/javascript">
    chart = google.charts.setOnLoadCallback(draw<?php echo e($model->id); ?>)

    function draw<?php echo e($model->id); ?>() {
        var data = google.visualization.arrayToDataTable([
            ['Element', "<?php echo e($model->element_label); ?>"],
            <?php for($i = 0; $i < count($model->values); $i++): ?>
                ["<?php echo e($model->labels[$i]); ?>", <?php echo e($model->values[$i]); ?>],
            <?php endfor; ?>
        ])

        var options = {
            <?php echo $__env->make('charts::_partials.dimension.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            fontSize: 12,
            <?php if($model->title): ?>
                title: "<?php echo e($model->title); ?>",
            <?php endif; ?>
            <?php if($model->colors): ?>
                colors: ["<?php echo e($model->colors[0]); ?>"],
            <?php endif; ?>
            legend: { position: 'top', alignment: 'end' }
        };

        var <?php echo e($model->id); ?> = new google.visualization.AreaChart(document.getElementById("<?php echo e($model->id); ?>"))

        <?php echo e($model->id); ?>.draw(data, options)
    }
</script>

<?php if(!$model->customId): ?>
    <?php echo $__env->make('charts::_partials.container.div', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
