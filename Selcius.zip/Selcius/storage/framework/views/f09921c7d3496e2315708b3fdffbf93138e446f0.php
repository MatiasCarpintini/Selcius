<?php if(!$model->customId): ?>
    <?php echo $__env->make('charts::_partials.container.canvas2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>

<script type="text/javascript">
    var ctx = document.getElementById("<?php echo e($model->id); ?>")

    var data = {
        labels: [
            <?php $__currentLoopData = $model->labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                "<?php echo e($label); ?>",
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        ],
        datasets: [{
            fill: true,
            <?php if($model->colors): ?>
                backgroundColor: "<?php echo e($model->colors[0]); ?>",
            <?php endif; ?>
            label: "<?php echo e($model->element_label); ?>",
            lineTension: 0.3,
            <?php if($model->colors): ?>
                borderColor: "<?php echo e($model->colors[0]); ?>",
            <?php endif; ?>
            data: [
                <?php $__currentLoopData = $model->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dta): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <?php echo e($dta); ?>,
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            ],
        }]
    };

    var myLineChart = new Chart(ctx, {
        type: 'line',
        data: data,
        options: {
            responsive: <?php echo e($model->responsive || !$model->width ? 'true' : 'false'); ?>,
            maintainAspectRatio: false,
            <?php if($model->title): ?>
                title: {
                    display: true,
                    text: "<?php echo e($model->title); ?>",
                    fontSize: 20,
                }
            <?php endif; ?>
        }
    });
</script>
