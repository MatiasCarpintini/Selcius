<p>
	<?php echo e($channel->otherUser()->name); ?>

</p>