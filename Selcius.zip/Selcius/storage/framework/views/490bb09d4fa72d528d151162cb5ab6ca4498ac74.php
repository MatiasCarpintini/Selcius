<?php $__env->startSection('title', '| Eliminar Comentario?'); ?>

<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->id != $comment->user_id): ?>
<h1>Acceso Denegado!</h1>
<?php else: ?>	
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<h1>En verdad desea Eliminar el Comentario?</h1>
			<p>
				<strong>Nombre:</strong> <?php echo e($comment->name); ?><br>
				<strong>E-mail:</strong> <?php echo e($comment->email); ?><br>
				<strong>Comentario:</strong> <?php echo e($comment->comment); ?>

			</p>

			<?php echo e(Form::open(['route' => ['comments.destroy', $comment->id], 'method' => 'DELETE'])); ?>

				<?php echo e(Form::submit('Eliminar!', ['class' => 'btn btn-lg btn-block btn-danger'])); ?>

			<?php echo e(Form::close()); ?>

		</div>
	</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>