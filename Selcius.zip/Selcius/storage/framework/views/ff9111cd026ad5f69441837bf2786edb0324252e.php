<?php $__env->startSection('title', '| Artículos'); ?>
<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->level == 2): ?>
<p class="flow-text text-center" style="font-size: 40px;">Artículos <a href="<?php echo e(route('articulos.create')); ?>" class="btn-floating btn-large waves-effect waves-light red" style="float:right;"><i class="material-icons">add</i></a></p>
<?php echo $chart->render(); ?>

<?php echo $donut->render(); ?>

<div class="row">
	<div class="col-md-13">
		<table class="striped">
			<thead>
				<tr>
					<th>#</th>
					<th>Título</th>
					<th>Creado el</th>
					<th>Autor</th>
					<th>Acciones</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					<tr>
						<td><?php echo e($articulo->id); ?></td>
						<td><?php echo e($articulo->title); ?></td>
						<td><?php echo e(date('M j, Y h:ia', strtotime( $articulo->created_at))); ?></td>
						<td><a href="<?php echo e('auth.profiles', $articulo->user->id); ?>"><?php echo e($articulo->user->name); ?></a></td>
						<td><a href="<?php echo e(route('articulos.show', $articulo->id)); ?>" style="margin-right: 10px;"><i class="fa fa-arrow-right"></i></a>
						<?php if(Auth::user()->id != $articulo->user_id): ?>

						<?php else: ?>
						<a href="<?php echo e(route('articulos.edit', $articulo->id)); ?>"><i class="fa fa-pencil"></i></a></td>
						<?php endif; ?>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</tbody>
		</table>
		<div class="text-center">
			<?php echo $articulos->links();; ?>

		</div>
	</div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>