<?php $__env->startSection('title', '| Uploads'); ?>

<?php $__env->startSection('content'); ?>

     <?php if(Auth::user()->level == 2): ?>

		

     <?php else: ?>

		Accesso denegado!

     <?php endif; ?>
     <?php if(Auth::user()->stripe_active == 2): ?>

		

     <?php else: ?>

		Accesso denegado!

     <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>