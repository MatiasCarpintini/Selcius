<?php if(Session::has('success')): ?>

	<div class="alert alert-success" role="alert">
		<p><i class="fa fa-check"></i> Exito: <?php echo e(Session::get('success')); ?></p>
	</div>

<?php endif; ?>

<?php if(count($errors) > 0): ?>

	<div class="alert alert-danger" role="alert">
		<p><i class="fa fa-times"></i> Error:
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			<?php echo e($error); ?>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</p>
	</div>

<?php endif; ?>
