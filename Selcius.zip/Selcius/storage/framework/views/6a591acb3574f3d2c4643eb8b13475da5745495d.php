<?php $__env->startSection('title', '| Foros'); ?>

<?php $__env->startSection('content'); ?>
<?php if(Auth::guest()): ?>

<?php else: ?>
<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
<?php if(Auth::user()->level == 2): ?>
    <?php echo $chart->render(); ?>

    <?php echo $donut->render(); ?>

<?php endif; ?>
<div class="row">
  <?php $__currentLoopData = $foros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foro): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <div class="card">
      <div class="card-content">
      <p style="font-family: 'Quicksand', sans-serif;font-size: 40px;">
        <a href="<?php echo e(route('auth.profiles', $foro->user->id)); ?>">
          <img src="<?php echo e(asset('avatars/'.$foro->user->image)); ?>" style="width: 42px;height: 42px;border-radius: 50%;margin-right: 10px;" class="responsive-img">
        </a>
        <a href="<?php echo e(route('foros.show', $foro->slug)); ?>"><?php echo e($foro->title); ?></a>
      </p>
      <br>
      <li class="divider"></li>
      <br>
      <p><?php echo substr(strip_tags($foro->body), 0, 355); ?><?php echo strlen(strip_tags($foro->body)) > 355 ? '...' : ""; ?></p>
      <p align="right"><i class="fa fa-clock-o"></i> <?php echo e(date('F nS, Y - g:iA', strtotime($foro->created_at))); ?> - <i class="fa fa-comments-o"></i> <?php echo e($foro->answers->count()); ?></p>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
<div class="fixed-action-btn horizontal click-to-toggle">
  <a class="btn-floating btn-large waves-effect waves-light blue" href="<?php echo e(route('foros.create')); ?>"><i class="material-icons">add</i></a>
</div>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>