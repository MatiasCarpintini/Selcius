<?php $__env->startSection('title', '| Comentarios'); ?>

<?php $__env->startSection('content'); ?>

	<?php if(Auth::guest()): ?>

	<h1 class="text-center">Acceso denegado!</h1>

	<?php else: ?>

		<div class="row">
		<div class="col-md-12">
			<table class="table">
				<thead>
					<th>
						#
					</th>
					<th>
						Usuario
					</th>
					<th>
						Comentario
					</th>
					<th>
						Creado el
					</th>
					<th>
						Artículo
					</th>
					<th></th>
				</thead>
				<tbody>
					<?php foreach($comments as $comment): ?>
						
						<tr><?php foreach($articulos as $articulo): ?>
							<th><?php echo e($comment->id); ?></th>
							<td><?php echo e($comment->name); ?></td>
							<td><?php echo e(substr(strip_tags($comment->comment),0,50)); ?><?php echo e(strlen(strip_tags($comment->comment)) > 50 ? "..." : ""); ?></td>
							<td><?php echo e(date('M j, Y h:ia', strtotime( $comment->created_at))); ?></td>
							<td><?php echo e($comment->articulo_id); ?></td>
							<td>
							<a href="<?php echo e(route('articulos.show', $articulo->id)); ?>" class="btn btn-default btn-sm">Ver</a>
							<?php if(Auth::user()->name != $articulo->name): ?>

							<?php else: ?>

							<a href="<?php echo e(route('comments.edit', $comment->id)); ?>" class="btn btn-success btn-sm">Editar</a></td>

							<?php endif; ?>
							
<?php endforeach; ?>
						</tr>
						
					<?php endforeach; ?>
				</tbody>
			</table>
			<div class="text-center">

				<?php echo $articulos->links();; ?>


			</div>


		</div>
	</div>

	<?php endif; ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>