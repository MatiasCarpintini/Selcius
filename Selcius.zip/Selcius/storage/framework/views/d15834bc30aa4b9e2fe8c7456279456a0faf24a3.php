<?php $titleTag = htmlspecialchars($discussion->title); ?>

<?php $__env->startSection('title', "| Editar - $titleTag"); ?> 

<?php $__env->startSection('stylesheets'); ?>
	<?php echo Html::style('css/parsley.css'); ?>

	<?php echo Html::style('css/select2.min.css'); ?>

    <script src="//cdn.tinymce.com/4/tinymce.min.js"></script>

    <script>
        tinymce.init({
            selector: "textarea",
            plugins: "link code, emoticons, fullscreen, lists",
            toolbar: "emoticons",
            menubar: true
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			
		<?php echo Form::model($discussion, ['route' => ['discussions.update', $discussion->slug],'method' => 'PUT']); ?>


			<?php echo e(Form::label('title', 'Título:')); ?>

				<?php echo e(Form::text('title', null, ['class' => 'form-control', 'required' => '', 'maxlength' => '255'])); ?>


				<?php echo e(Form::label('slug', 'Slug:')); ?>

				<?php echo e(Form::text('slug', null, ['class' => 'form-control', 'required' => '', 'minlenght' => '5', 'maxlenght' => '255'])); ?>


				<?php echo e(Form::label('name', 'Usuario:')); ?>

				<?php echo e(Form::text('name', null, ['class' => 'form-control', 'required' => '', 'maxlenght' => '255'])); ?>


				<?php echo e(Form::label('email', 'E-mail:')); ?>

				<?php echo e(Form::text('email', null, ['class' => 'form-control'])); ?>


				<?php echo e(Form::label('description', 'Descripción')); ?>

				<?php echo e(Form::textarea('description', null, ['class' => 'form-control'])); ?>


		</div>
		<div class="col-md-4">
			<div class="well"><dl class="dl-horizontal">
				<dt>Creado el:</dt>
				<dd><?php echo e(date('M j, Y h:ia', strtotime($discussion->created_at))); ?></dd>
			</dl>
			<dl class="dl-horizontal">
				
			<dt>Última Actualización:</dt>
			<dd><?php echo e(date('M j, Y h:ia', strtotime($discussion->updated_at))); ?></dd>
			</dl>
				<hr>
				<div class="row">
					<div class="col-sm-6">
						<?php echo Html::linkRoute('discussions.show', 'Cancelar', [$discussion->id], ['class' => 'btn btn-danger btn-lg btn-block']); ?>

					</div>
					<div class="col-sm-6">
					<?php echo e(Form::submit('Actualizar', ['class' => 'btn btn-success btn-lg btn-block'])); ?>

					</div>
				</div>
			</div>
		</div>
		<?php echo Form::close(); ?>

	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>