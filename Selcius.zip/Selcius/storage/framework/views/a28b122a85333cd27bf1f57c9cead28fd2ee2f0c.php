<?php $titleTag = htmlspecialchars($users->name); ?>

<?php $__env->startSection('title', "| $titleTag"); ?> 

<?php $__env->startSection('content'); ?>

	<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
        <?php foreach($users as $user): ?>
            <img src="/images/users/<?php echo e($user->image); ?>" style="width:150px; height:150px; float:left; border-radius:50%; margin-right:25px;">
            <h2><?php echo e($user->name); ?></h2>
            <form enctype="multipart/form-data" action="/profile" method="POST">
                <label>Update Profile Image</label>
                <input type="file" name="image">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <input type="submit" class="pull-right btn btn-sm btn-primary">
            </form>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>