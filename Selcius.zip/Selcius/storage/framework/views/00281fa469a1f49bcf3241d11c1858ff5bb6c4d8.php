<script type="text/javascript">
    FusionCharts.ready(function () {
        var <?php echo e($model->id); ?> = new FusionCharts({
            type: 'area2d',
            renderAt: "<?php echo e($model->id); ?>",
            <?php echo $__env->make('charts::_partials.dimension.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            dataFormat: 'json',
            dataSource: {
                'chart': {
                    <?php if($model->title): ?>
                    'caption': "<?php echo e($model->title); ?>",
                    <?php endif; ?>
                    'yAxisName': "<?php echo e($model->element_label); ?>",
                    <?php if($model->colors): ?>
                        'paletteColors': "<?php echo e($model->colors[0]); ?>",
                    <?php endif; ?>
                    'bgColor': '#ffffff',
                    'borderAlpha': '20',
                    'canvasBorderAlpha': '0',
                    'usePlotGradientColor': '0',
                    'plotBorderAlpha': '10',
                    'rotatevalues': '0',
                    'showValues': '0',
                    'valueFontColor': '#ffffff',
                    'showXAxisLine': '1',
                    'xAxisLineColor': '#999999',
                    'divlineColor': '#999999',
                    'divLineIsDashed': '1',
                    'showAlternateHGridColor': '0',
                    'subcaptionFontBold': '0',
                    'subcaptionFontSize': '14'
                },
                'data': [
                    <?php for($i = 0; $i < count($model->values); $i++): ?>
                        {
                            'label': "<?php echo e($model->labels[$i]); ?>",
                            'value': <?php echo e($model->values[$i]); ?>,
                        },
                    <?php endfor; ?>
                ],
            }
        }).render()
    });
</script>

<?php echo $__env->make('charts::_partials.container.div', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
